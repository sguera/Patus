This example takes an image and applies a filter, defined in the stencil specification filter.stc, to it.
To build, libpng-dev needs to be installed on your system.
(If it isn't installed, e.g. on Ubuntu, use "sudo apt-get install libpng-dev" to install it.)
